# Design System Document

## 1. Overview & Creative North Star: "The Curated Gallery"

This design system is built upon the philosophy of **"The Curated Gallery."** It moves away from the noisy, cluttered "template" look of traditional portfolios in favor of an editorial, high-end experience. The North Star for this system is intentionality; every pixel of white space is treated as an active design element, and every transition of color is a silent guide for the user’s eye.

By utilizing **Indigo (`primary`)** as a sophisticated anchor against a vast, airy landscape of **Subtle Grays (`surface` variants)**, we create an environment that feels both authoritative and approachable. We break the grid through **intentional asymmetry**: large-scale typography may bleed off-center, and imagery should overlap container boundaries to create a sense of three-dimensional layering.

---

## 2. Colors & Surface Architecture

### The Palette
The color strategy relies on the depth of Indigo to convey "Professionalism" while using a wide range of neutral surfaces to provide "Modernity."
- **Primary (`#24389c`):** Use for high-impact brand moments and key CTAs.
- **Surface Tiers:** Use `surface_container_lowest` (#ffffff) for primary content cards and `surface` (#f8f9fa) for the main page background.

### The "No-Line" Rule
**Explicit Instruction:** Do not use 1px solid borders to define sections or containers. Modern luxury is defined by transitions in tone, not structural scaffolding. 
- Define boundaries by placing a `surface_container_lowest` card on top of a `surface_container_low` background. 
- Use white space (minimum 80px - 120px between sections) to signify the end of a thought.

### The "Glass & Gradient" Rule
To add a "Personal Touch" and visual soul:
- **Signature Gradients:** Apply a subtle linear gradient from `primary` (#24389c) to `primary_container` (#3f51b5) on hero backgrounds or primary buttons to avoid a "flat" corporate feel.
- **Glassmorphism:** Use `surface_container_lowest` at 70% opacity with a `24px` backdrop-blur for floating navigation bars. This ensures the portfolio feels integrated and fluid.

---

## 3. Typography: Editorial Authority

We use a dual-sans-serif approach to balance character with readability.

*   **Display & Headlines (Manrope):** Chosen for its geometric yet warm structure. Use `display-lg` (3.5rem) for hero statements. To achieve the "Editorial" look, decrease letter-spacing to `-0.02em` on headlines.
*   **Body & Labels (Inter):** Inter provides clinical precision for long-form text. It ensures that your skills and project descriptions are legible at any scale.

**The Hierarchy Rule:**
- **Asymmetric Pairing:** Align `display-md` headlines to the left, but offset the `body-lg` descriptive text to the right-third of the grid. This tension creates a "designed" rather than "default" feel.

---

## 4. Elevation & Depth: Tonal Layering

Traditional drop shadows are forbidden. We achieve depth through **The Layering Principle**.

*   **Stacking:** 
    1.  Base: `surface`
    2.  Section: `surface_container_low`
    3.  Component/Card: `surface_container_lowest` (White)
*   **Ambient Shadows:** If a card must float (e.g., a hover state), use a shadow color derived from `on_surface` at 4% opacity with a `40px` blur and `10px` Y-offset. It should feel like a soft glow of light, not a shadow.
*   **The "Ghost Border":** For interactive elements like input fields, use the `outline_variant` (#c5c5d4) at 30% opacity. It should be barely perceptible, serving only as a subtle hint of a boundary.

---

## 5. Components

### Sophisticated Navigation
- **The Floating Dock:** A centered, pill-shaped (`rounded-full`) navigation bar using a Glassmorphic `surface_container_lowest`. 
- **Active State:** Instead of an underline, use a small `primary` dot below the text or transition the text color to `primary`.

### High-Impact Hero Sections
- **Layout:** Use `display-lg` typography. Overlap the bottom of the text with a high-quality project image. 
- **The "Signature" CTA:** A `primary` button with a subtle gradient and `xl` (0.75rem) rounded corners.

### Refined Project Cards
- **No Borders/Dividers:** Cards are defined by their white `surface_container_lowest` background against the `surface_container_low` page color.
- **Spacing:** Use 32px internal padding to allow imagery and text to breathe.
- **Hover State:** A subtle scale-up (1.02x) and a transition from `surface_container_lowest` to a very faint `primary_fixed` tint.

### Inputs & Skills Chips
- **Chips:** Use `secondary_container` with `on_secondary_container` text. Keep them `rounded-full` for a soft, approachable feel.
- **Inputs:** Use `surface_container_high` as the background with no border. On focus, transition the background to `surface_container_lowest` with a 1px `primary` Ghost Border (20% opacity).

---

## 6. Do's and Don'ts

### Do:
- **Do** use "Negative Space" as a luxury. If a section feels crowded, double the padding.
- **Do** use `tertiary` (#6c3400) sparingly for small accents—like a "New" tag or a link hover—to provide a warm counterpoint to the Indigo.
- **Do** align text to a 4px baseline grid to maintain editorial rhythm.

### Don't:
- **Don't** use pure black (#000000). Always use `on_surface` (#191c1d) for text to keep the contrast "soft-premium."
- **Don't** use 1px dividers. If you feel the need to separate items in a list, use an extra 16px of vertical white space instead.
- **Don't** use standard "Blue." Always stick to the `primary` Indigo (#24389c) to maintain the brand's sophisticated "Personal Touch."

---

## 7. Signature Interaction Pattern
When transitioning between pages or opening project cards, use a **Staggered Reveal**. Elements should not just "appear"; they should slide up 20px while fading in, with a slight delay between the headline, the image, and the body text. This mimics the feeling of a curator unveiling an exhibit.